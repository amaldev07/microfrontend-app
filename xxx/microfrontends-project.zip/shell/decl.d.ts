
declare module 'profile/ProfileComponent' {
  export const ProfileComponent: any;
}

declare module 'dashboard/DashboardComponent' {
  export const DashboardComponent: any;
}
